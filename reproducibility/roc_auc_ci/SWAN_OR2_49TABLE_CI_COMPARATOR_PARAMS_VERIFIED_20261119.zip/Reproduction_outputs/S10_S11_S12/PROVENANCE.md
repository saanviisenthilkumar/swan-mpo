# S10–S12 recovered-source verification

This file documents sources and independent checks added after the 49-table numerical audit. All 49 originally published supplementary table CSVs remain byte-for-byte unchanged.

## S10: Kendall rank agreement

The 20 `d_QED` records in `Reproduction_inputs/S10_clean_QED_input_20.csv` were extracted from `phase12_INTERNAL_swan_vs_qed_simple_mpo_HEAD_TO_HEAD_FIXED.csv`, original historical SHA-256 `f1f0b92d892a81960c9ae730d598ce5cb93768213476bddc1883303de0dfc8c9`.

The recovered Phase 12 file contained eight historical `5AR2` references in an unrelated `second_best_node` diagnostic column. That column is intentionally excluded from the clean source and all calculations. The verifier reconstructs QED-only rankings and equal-weight QED–ADME–BestNode geometric-mean rankings using **current eight-target Table S8A**, then compares all six Kendall tau and p-value rows. Largest numerical error: `8.326672684688674e-17`.

## S11–S12: broad ChEMBL synthetic-profile cohort

`Reproduction_inputs/S11_S12_broad_chembl_corrected_profiles_3980.csv` is the unmodified 3,980-row historical source from `six_target_995/results/broad_chembl_corrected_profiles.csv` in `SWAN_S11_TWO_COHORT_REPRO_20261116_114247.zip`. Its SHA-256 is `2c21418b488f59377744dde2797b38740a1c9bd9f4b69bdabff4ff61df092490`.

This cohort has **995 ChEMBL actives and 2,985 generated synthetic comparison profiles**, not 2,985 assay-confirmed inactive molecules. The source generator's historical NumPy random seed is 2026 with a 3:1 synthetic-to-active ratio; safety and liability are held at 0.50 and 0.60 in both classes. `Reproduction_inputs/S11_S12_995_active_source.csv` and `Reproduction_scripts/historical_s11_profile_generator.py` are included as upstream lineage evidence. The original generator is historical and may use a different tie convention for selected auxiliary outputs; the publication tables are verified by the separate independent script.

Published S11/S12 scores are mapped as follows:

| Published label | Source score field |
|---|---|
| SWAN-MPO | `swan_corrected_symmetric` |
| Binding-only | `d_binding` |
| ADME-only | `d_adme` |

The historical generator's distinct `adme_only` score is **not** used to reconstruct the published S11 and S12 comparisons. Likewise, the separate 4,388-row cohort is not interchangeable with the 3,980-row published cohort.

Independent calculations reproduced all 12 S11 AUC, tie-averaged BEDROC, EF@1%, and EF@5% cells within their reported rounding. All 24 numeric cells across S12's three paired DeLong comparisons reproduced, maximum absolute error `2.5757174171303632e-14`. The S12 ROC-AUC for ADME-only (0.809961) exceeds the integrated variant (0.801860), with a nonsignificant paired difference (`p=0.061262`); no integrated superiority claim is warranted for this cohort.

## Reproduce

From the extracted root of Online Resource 2:

```bash
python Reproduction_scripts/verify_s10_s11_s12.py /absolute/path/to/this_OR2.zip
```

Dependencies: Python 3, NumPy, pandas, SciPy, scikit-learn. The verifier checks its 3,980-row source SHA, computes directly from source data without reading original S11/S12 numerical results until comparison, and does not modify any file.

## Remaining scope limitations

Original docking outputs/receptor preparations, the full 738,801-compound COCONUT source, and certain older generator/adaptor implementations remain separate upstream provenance dependencies. They are not silently claimed to be present in this archive. The historical 15-compound S16 and full-universe S22 results have previously been independently reconstructed, with their verification scripts supplied in this package. Internal ranking and synthetic-profile benchmarking do not establish prospective anticancer efficacy, toxicity safety, or experimentally confirmed inactive discrimination.
