#!/usr/bin/env python3
"""Reproduce all 80 S13 BEDROC alpha=20 values from published S13A records.

Standard-library only. Usage after unpacking Online Resource 2:
    python Reproduction_scripts/verify_s13_tie_averaged_bedroc.py

The tie rule replaces each score-tied observation's exponential rank weight
with the arithmetic mean of the exponential weights in its occupied ranks.
"""

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
FIELDS = {
    "binding_only": "binding_only",
    "adme_only": "adme_only",
    "liability_only": "structure_derived_liability",
    "binding_adme_gm": "binding_adme_gm",
    "binding_liability_gm": "binding_liability_gm",
    "adme_liability_gm": "adme_liability_gm",
    "integrated_gm3": "integrated_gm3",
    "integrated_arithmetic3": "integrated_arithmetic3",
    "integrated_min3": "integrated_min3",
    "qed": "qed",
}
A = "A_active_approved_no_serious_warning"
B = "B_active_serious_warning"
C = "C_inactive_approved_no_serious_warning"


def read(filename):
    with (ROOT / filename).open(newline="", encoding="utf-8-sig") as inp:
        return list(csv.DictReader(inp))


def bedroc(rows, score_col, alpha=20.0):
    records = sorted(
        [(float(row[score_col]), int(row["benchmark_y"])) for row in rows],
        key=lambda pair: -pair[0],
    )
    n = len(records)
    positives = sum(label for _, label in records)
    if positives == 0:
        return 0.0
    if positives == n:
        return 1.0
    discounts = [math.exp(-alpha * rank/n) for rank in range(1, n+1)]
    numerator = 0.0
    start = 0
    while start < n:
        end = start + 1
        while end < n and records[end][0] == records[start][0]:
            end += 1
        positive_count = sum(label for _, label in records[start:end])
        numerator += positive_count * (sum(discounts[start:end]) / (end-start))
        start = end
    prevalence = positives/n
    rie = (numerator / (prevalence * sum(discounts)))
    max_rie = (1-math.exp(-alpha*prevalence))/(prevalence*(1-math.exp(-alpha)))
    min_rie = (1-math.exp(alpha*prevalence))/(prevalence*(1-math.exp(alpha)))
    return (rie-min_rie)/(max_rie-min_rie)


def main():
    source = read("Table_S13A_ChEMBL_activity_status_records.csv")
    assert len(source) == 188
    assert all(r["target_label"] != "5AR2" for r in source)
    counts = {}
    for table, filename in [
        ("S13B", "Table_S13B_ChEMBL_activity_status_performance.csv"),
        ("S13C", "Table_S13C_ChEMBL_domain_contribution.csv"),
        ("S13D", "Table_S13D_ChEMBL_target_stratified_metrics.csv"),
    ]:
        matched = 0
        for row in read(filename):
            if table == "S13B":
                if row["section"] != "primary_performance":
                    continue
                cohort = source
            elif table == "S13C":
                if row["analysis_type"] != "metrics":
                    continue
                if row["contrast"] == "A_vs_B_active_favorable_vs_active_serious_warning":
                    cohort = [r for r in source if r["benchmark_group"] in (A, B)]
                elif row["contrast"] == "A_vs_C_active_favorable_vs_weak_inactive_favorable":
                    cohort = [r for r in source if r["benchmark_group"] in (A, C)]
                else:
                    raise ValueError(row["contrast"])
            else:
                if row["section"] != "descriptive_performance":
                    continue
                cohort = [r for r in source if r["target_label"] == row["target_label"]]
            observed = float(row["bedroc_alpha20"])
            expected = bedroc(cohort, FIELDS[row["score_implementation"]])
            assert abs(observed - expected) < 5e-12, (table, row["score_implementation"], observed, expected)
            matched += 1
        counts[table] = matched
    assert counts == {"S13B": 10, "S13C": 20, "S13D": 50}, counts
    print("PASS: 80/80 S13 BEDROC alpha=20 values reproduced (ties averaged); 188 records, 5AR2 excluded.")


if __name__ == "__main__":
    main()
