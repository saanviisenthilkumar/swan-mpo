#!/usr/bin/env python3
# Independent reconstructed verifier for SWAN-MPO S22 COCONUT.
# This is NOT the original historical Phase 10 generator.

import argparse
import zipfile
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

FEATURES = [
    "MW", "logP", "TPSA", "HBD", "HBA",
    "rotatable_bonds", "heavy_atom_count",
    "Global_NP_ADME_desirability"
]

def upper(x, preferred, minimum):
    return np.clip(
        1 - 0.99 * np.maximum(x - preferred, 0) /
        (minimum - preferred),
        0.01, 1.0
    )

def logp_score(x):
    y = np.ones_like(x, dtype=float)
    low = x < 0
    high = x > 5
    y[low] = 1 - 0.99 * (-x[low]) / 2
    y[high] = 1 - 0.99 * (x[high] - 5) / 3
    return np.clip(y, 0.01, 1.0)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scored", required=True)
    parser.add_argument("--or2", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.scored, low_memory=False)
    n = len(df)

    assert n == 738801
    assert df["compound_id"].is_unique

    predicted = {
        "d_MW": upper(df.MW.to_numpy(float), 500, 900),
        "d_logP": logp_score(df.logP.to_numpy(float)),
        "d_TPSA": upper(df.TPSA.to_numpy(float), 140, 250),
        "d_rotB": upper(df.rotatable_bonds.to_numpy(float), 10, 20),
        "d_HBD": upper(df.HBD.to_numpy(float), 5, 10),
        "d_HBA": upper(df.HBA.to_numpy(float), 10, 20),
    }

    for column, values in predicted.items():
        error = np.max(
            np.abs(values - df[column].to_numpy(float))
        )
        assert error < 1e-8, (column, error)

    components = np.column_stack(list(predicted.values()))
    calculated_scores = np.exp(np.mean(np.log(components), axis=1))

    score_error = np.max(np.abs(
        calculated_scores -
        df.Global_NP_ADME_desirability.to_numpy(float)
    ))
    assert score_error < 1e-8

    ranks = df.global_rank.to_numpy(float)
    assert np.isfinite(ranks).all()
    assert np.all(ranks == np.rint(ranks))
    assert len(np.unique(ranks)) == n
    assert ranks.min() == 1 and ranks.max() == n

    rank_order = np.argsort(ranks, kind="stable")
    assert np.all(
        np.diff(calculated_scores[rank_order]) <= 1e-9
    )

    pct = 100 * (1 - (ranks - 1) / (n - 1))
    assert np.max(np.abs(
        pct - df.percentile.to_numpy(float)
    )) < 1e-8

    matrix = df[FEATURES].to_numpy(float)
    assert np.isfinite(matrix).all()

    scaler = StandardScaler()
    scaled = scaler.fit_transform(matrix)

    pca = PCA(n_components=2, svd_solver="full")
    coordinates = pca.fit_transform(scaled)

    for k in range(2):
        pivot = np.argmax(np.abs(pca.components_[k]))
        if pca.components_[k, pivot] < 0:
            pca.components_[k] *= -1
            coordinates[:, k] *= -1

    mur = df.compound_id.astype(str).str.contains(
        "Muricatacin", case=False, na=False
    )

    assert mur.sum() == 1
    mur_index = np.flatnonzero(mur.to_numpy())[0]

    distances = np.hypot(
        coordinates[:, 0] - coordinates[mur_index, 0],
        coordinates[:, 1] - coordinates[mur_index, 1]
    )
    distances[mur_index] = np.inf

    ids = df.compound_id.astype(str).to_numpy()
    nearest = np.lexsort((ids, distances))[:100]

    with zipfile.ZipFile(args.or2) as archive:
        model = pd.read_csv(
            archive.open("Table_S22C_COCONUT_PCA_model.csv")
        )
        neighbors = pd.read_csv(
            archive.open("Table_S22B_COCONUT_nearest_neighbors.csv")
        )
        variance = pd.read_csv(
            archive.open(
                "Reproduction_outputs/S22_full_universe/"
                "S22_PCA_explained_variance.csv"
            )
        )

    assert model.descriptor.tolist() == FEATURES

    assert np.allclose(
        model.scaler_mean.to_numpy(float),
        scaler.mean_,
        rtol=1e-9, atol=1e-8
    )

    assert np.allclose(
        model.scaler_scale.to_numpy(float),
        scaler.scale_,
        rtol=1e-9, atol=1e-8
    )

    assert np.allclose(
        model[["PC1_loading", "PC2_loading"]].to_numpy(float).T,
        pca.components_,
        rtol=1e-8, atol=1e-8
    )

    assert np.allclose(
        variance.variance_explained.to_numpy(float),
        pca.explained_variance_ratio_,
        rtol=1e-8, atol=1e-10
    )

    assert neighbors.compound_id.astype(str).tolist() == (
        ids[nearest].tolist()
    )

    assert np.allclose(
        neighbors["distance_to_muricatacin_PC1PC2"].to_numpy(float),
        distances[nearest],
        rtol=1e-8, atol=1e-9
    )

    print("COCONUT source records:", n)
    print("Six desirability components: PASS")
    print("Final ADME scores: PASS")
    print("Global ranks and percentiles: PASS")
    print("S22C PCA model: PASS")
    print("S22 explained variance: PASS")
    print("S22B nearest neighbors: 100/100 PASS")
    print("RECONSTRUCTED S22 VERIFIER: ALL CHECKS PASSED")

if __name__ == "__main__":
    main()
