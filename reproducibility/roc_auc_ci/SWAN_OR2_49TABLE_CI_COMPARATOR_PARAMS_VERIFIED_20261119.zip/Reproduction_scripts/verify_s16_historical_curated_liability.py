#!/usr/bin/env python3
"""Independent reconstruction of the historical 15-compound S16 analysis.

Uses archived Table S4A and S16 data.
This is a source-derived verifier, NOT the recovered historical generator.
"""

import sys
import json
import zipfile
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


def normalized_bedroc(labels, scores, alpha=20):
    labels = np.asarray(labels, dtype=int)
    scores = np.asarray(scores, dtype=float)

    n = len(labels)
    n_positive = int(labels.sum())

    assert 0 < n_positive < n

    order = np.argsort(-scores, kind="mergesort")
    ranked_scores = scores[order]
    ranked_labels = labels[order]

    observed = 0.0
    start = 0

    while start < n:
        end = start + 1

        while (
            end < n
            and ranked_scores[end] == ranked_scores[start]
        ):
            end += 1

        positions = np.arange(start + 1, end + 1)

        discount = np.exp(
            -alpha * positions / n
        ).mean()

        observed += (
            ranked_labels[start:end].sum() * discount
        )

        start = end

    best_positions = np.arange(1, n_positive + 1)
    worst_positions = np.arange(
        n - n_positive + 1, n + 1
    )

    best = np.exp(
        -alpha * best_positions / n
    ).sum()

    worst = np.exp(
        -alpha * worst_positions / n
    ).sum()

    return float(
        (observed - worst) / (best - worst)
    )


def verify_zip(archive_path):
    with zipfile.ZipFile(archive_path) as archive:
        source = pd.read_csv(archive.open(
            "Table_S4A_retrospective_benchmark_manifest_PRIMARY.csv"
        ))

        expected = pd.read_csv(archive.open(
            "Table_S16_curated_liability_ablation_summary.csv"
        ))

    assert len(source) == 15
    assert len(expected) == 21
    assert source["Compound"].is_unique

    labels = source["label"].to_numpy(dtype=int)

    raw_scores = source[
        "SWAN_BestNode_raw"
    ].to_numpy(dtype=float)

    stored_curated_scores = source[
        "SWAN_BestNode_curated_liability"
    ].to_numpy(dtype=float)

    raw_liability = source[
        "liability_score_raw"
    ].to_numpy(dtype=float)

    stored_curated_liability = source[
        "liability_score_curated"
    ].to_numpy(dtype=float)

    flag_columns = [
        "curated_chronic_toxicity_flag",
        "curated_genotoxic_hepatotoxicity_flag",
        "curated_hepatotoxicity_flag",
        "curated_nephrotoxicity_flag",
    ]

    flags = source[flag_columns].apply(
        pd.to_numeric, errors="coerce"
    ).fillna(0)

    assert np.all(raw_liability > 0)
    assert np.all(np.isfinite(raw_scores))

    flag_counts = flags.sum(axis=1).to_numpy()

    stored_counts = source[
        "n_curated_flags"
    ].to_numpy(dtype=float)

    assert np.array_equal(
        flag_counts, stored_counts
    ), "Historical toxicity-flag counts disagree."

    def calculate(active_flags):
        any_flag = active_flags.gt(0).any(
            axis=1
        ).to_numpy()

        toxicity_desirability = np.where(
            any_flag, 0.01, 1.0
        )

        liability = np.sqrt(
            raw_liability * toxicity_desirability
        )

        score = raw_scores * np.power(
            liability / raw_liability, 0.25
        )

        return liability, score

    reconstructed_liability, full_scores = calculate(flags)

    liability_error = float(np.max(np.abs(
        reconstructed_liability
        - stored_curated_liability
    )))

    full_score_error = float(np.max(np.abs(
        full_scores - stored_curated_scores
    )))

    assert liability_error <= 1e-8
    assert full_score_error <= 1e-8

    category_mapping = {
        "remove_hepatotoxic_flags":
            "curated_hepatotoxicity_flag",
        "remove_genotoxic_flags":
            "curated_genotoxic_hepatotoxicity_flag",
        "remove_nephrotoxic_flags":
            "curated_nephrotoxicity_flag",
        "remove_chronic_toxicity_flags":
            "curated_chronic_toxicity_flag",
    }

    maximum_error = 0.0
    verified = 0
    details = []

    for _, row in expected.iterrows():
        variant = str(row["variant"])

        if variant == "raw_automated_no_curated_liability":
            scores = raw_scores.copy()

        elif variant == "full_curated_liability":
            scores = full_scores.copy()

        elif variant in category_mapping:
            modified_flags = flags.copy()

            modified_flags[
                category_mapping[variant]
            ] = 0

            _, scores = calculate(modified_flags)

        elif variant.startswith(
            "revert_one_compound_to_raw__"
        ):
            compound = variant.split(
                "revert_one_compound_to_raw__", 1
            )[1]

            mask = source[
                "Compound"
            ].eq(compound).to_numpy()

            assert int(mask.sum()) == 1, compound

            scores = full_scores.copy()
            scores[mask] = raw_scores[mask]

        else:
            raise ValueError(
                f"Unrecognized S16 variant: {variant}"
            )

        calculated = {
            "ROC_AUC": float(
                roc_auc_score(labels, scores)
            ),
            "BEDROC_alpha20": normalized_bedroc(
                labels, scores, alpha=20
            ),
            "minimum_score": float(
                np.min(scores)
            ),
            "maximum_score": float(
                np.max(scores)
            ),
            "n_compounds": len(scores),
            "n_positive": int(labels.sum()),
            "n_negative": int(
                len(labels) - labels.sum()
            ),
        }

        errors = {
            name: abs(
                calculated[name] - float(row[name])
            )
            for name in calculated
        }

        error = max(errors.values())
        maximum_error = max(maximum_error, error)

        if error > 1e-6:
            raise AssertionError(
                f"{variant}: metric mismatch {errors}"
            )

        details.append({
            "variant": variant,
            "max_error": error,
            "status": "PASS",
        })

        verified += 1

    assert verified == 21

    return {
        "status": "PASS",
        "verification_type":
            "independent_source_derived_reconstruction",
        "original_historical_generator_recovered": False,
        "source_compounds": len(source),
        "verified_variants": verified,
        "maximum_metric_error": maximum_error,
        "maximum_curated_liability_error": liability_error,
        "maximum_full_score_error": full_score_error,
        "details": details,
    }


if __name__ == "__main__":
    result = verify_zip(sys.argv[1])
    print(json.dumps(result, indent=2))
