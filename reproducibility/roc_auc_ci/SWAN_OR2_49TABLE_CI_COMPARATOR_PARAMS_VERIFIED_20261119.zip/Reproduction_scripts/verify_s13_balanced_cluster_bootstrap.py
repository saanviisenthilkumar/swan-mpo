#!/usr/bin/env python3
"""Verify the reproducible 5,000-draw class-balanced S13C cluster bootstrap.

Run in a directory containing the extracted OR2 CSVs. The only computational
inputs are the final 188-row S13A score/label table and the declared seed.
The expected results are read from S13C *after* independent computation.

Requires numpy and pandas; does not require sklearn or network access.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


GROUPS = (
    "A_active_approved_no_serious_warning",
    "B_active_serious_warning",
    "C_inactive_approved_no_serious_warning",
)
FIELDS = (
    "binding_only", "adme_only", "liability_only",
    "binding_adme_gm", "binding_liability_gm", "adme_liability_gm",
    "integrated_gm3", "integrated_arithmetic3", "integrated_min3", "qed",
)
SOURCE_COLUMNS = {"liability_only": "structure_derived_liability"}
STATS = (
    "n_bootstrap_valid", "mean_delta_auc", "median_delta_auc",
    "ci_2_5", "ci_97_5", "prob_delta_gt_0",
)


def calculate(frame: pd.DataFrame, repetitions: int = 5000, seed: int = 2026) -> pd.DataFrame:
    """Parent-cluster resampling, within-resample group balancing, paired AUCs.

    Parent IDs are sorted lexicographically. In each draw, sample exactly the
    number of distinct parents from the original cohort, with replacement.
    Every sampled parent contributes all its original target records; repeated
    parents contribute repeated copies. Assign half the total weight to class
    A, one quarter to B and one quarter to C *within each valid draw*. The AUC
    uses a tie credit of 0.5 for equal positive/negative scores. The same draws
    and same group weights are used for all ten score variants.
    """
    assert len(frame) == 188
    assert tuple(sorted(frame.benchmark_group.unique())) == tuple(sorted(GROUPS))
    assert tuple(frame.groupby("benchmark_group").size().reindex(GROUPS)) == (44, 25, 119)
    assert set(frame.benchmark_y.unique()) == {0, 1}

    parents = np.sort(frame.parent_chembl_id.astype(str).unique())
    parent_numbers = pd.Index(parents).get_indexer(frame.parent_chembl_id.astype(str))
    assert (parent_numbers >= 0).all()
    rng = np.random.default_rng(seed)
    draws = rng.choice(len(parents), size=(repetitions, len(parents)), replace=True)
    counts = np.zeros((repetitions, len(parents)), dtype=np.float64)
    np.add.at(counts, (np.repeat(np.arange(repetitions), len(parents)), draws.ravel()), 1.0)
    record_counts = counts[:, parent_numbers]

    labels = frame.benchmark_y.to_numpy(int)
    a = np.flatnonzero(labels == 1)
    bc = np.flatnonzero(labels == 0)
    assert len(a) == 44 and len(bc) == 144
    neg_groups = frame.benchmark_group.to_numpy()[bc]
    b = neg_groups == GROUPS[1]
    c = neg_groups == GROUPS[2]
    assert b.sum() == 25 and c.sum() == 119

    a_weights = record_counts[:, a].copy()
    neg_weights = record_counts[:, bc].copy()
    a_tot = a_weights.sum(axis=1)
    b_tot = neg_weights[:, b].sum(axis=1)
    c_tot = neg_weights[:, c].sum(axis=1)
    valid = (a_tot > 0) & (b_tot > 0) & (c_tot > 0)
    assert valid.all(), f"Only {int(valid.sum())}/{repetitions} resamples have all three classes"
    a_weights = a_weights / a_tot[:, None] * 0.5
    neg_weights[:, b] = neg_weights[:, b] / b_tot[:, None] * 0.25
    neg_weights[:, c] = neg_weights[:, c] / c_tot[:, None] * 0.25

    aucs = {}
    for field in FIELDS:
        s = frame[SOURCE_COLUMNS.get(field, field)].to_numpy(float)
        pair_credit = (s[a, None] > s[None, bc]).astype(float)
        pair_credit += 0.5 * (s[a, None] == s[None, bc])
        aucs[field] = np.einsum("bi,ij,bj->b", a_weights, pair_credit, neg_weights, optimize=True) / 0.25

    output = []
    for comparator in FIELDS:
        if comparator == "integrated_gm3":
            continue
        delta = aucs["integrated_gm3"] - aucs[comparator]
        output.append({
            "reference": "integrated_gm3", "comparator": comparator,
            "n_bootstrap_valid": int(valid.sum()),
            "mean_delta_auc": float(delta.mean()),
            "median_delta_auc": float(np.median(delta)),
            "ci_2_5": float(np.percentile(delta, 2.5)),
            "ci_97_5": float(np.percentile(delta, 97.5)),
            # An equal-AUC contrast is not a win. Normalizing numerical
            # cancellation below 1e-12 prevents BLAS/NumPy-specific ULP
            # signs from changing an otherwise identical reported fraction.
            "prob_delta_gt_0": float(np.mean(delta > 1e-12)),
        })
    return pd.DataFrame(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=Path("."))
    args = parser.parse_args()
    directory = args.directory
    rows = pd.read_csv(directory / "Table_S13A_ChEMBL_activity_status_records.csv")
    reported = pd.read_csv(directory / "Table_S13C_ChEMBL_domain_contribution.csv")
    observed = reported.loc[
        (reported.analysis_type == "parent_clustered_bootstrap_delta_auc")
        & (reported.contrast.str.contains("balanced", case=False, na=False))
    ]
    assert len(observed) == 9, f"Expected 9 reported balanced contrasts; saw {len(observed)}"
    expected = calculate(rows)
    joined = observed.merge(expected, on=["reference", "comparator"], suffixes=("_reported", "_computed"), validate="one_to_one")
    assert len(joined) == 9
    for field in STATS:
        delta = np.abs(joined[field + "_reported"] - joined[field + "_computed"])
        assert np.all(delta < 5e-12), f"{field}: max error {delta.max()}"
    print("PASS: 9 class-balanced S13C comparisons x 6 statistics = 54 matching cells")
    print("PASS: 188 records, sorted parent clusters, seed=2026, 5000 valid draws")


if __name__ == "__main__":
    main()
