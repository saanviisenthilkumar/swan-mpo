#!/usr/bin/env python3
"""Independent, read-only checks of published OR2 S10–S12 against recovered inputs.

Usage:
  python verify_s10_s11_s12.py /path/to/SWAN_OR2_49TABLE_S16_S23_VERIFIED_REVIEW.zip

Requires numpy, pandas, scipy, and scikit-learn. Source inputs are in the
Reproduction_inputs directory adjacent to this script. No file is modified.
"""

import hashlib
import io
import math
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, norm
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
# Also works when installed in an OR2 archive under Reproduction_scripts/.
ROOT = HERE if (HERE / "Reproduction_inputs").exists() else HERE.parent
INPUTS = ROOT / "Reproduction_inputs"


def csv_from_zip(archive, name):
    return pd.read_csv(io.BytesIO(archive.read(name)))


def assert_close(what, observed, expected, tol=1e-12):
    error = abs(float(observed) - float(expected))
    if not np.isfinite(error) or error > tol:
        raise AssertionError(f"{what}: observed={observed}, expected={expected}, error={error}")
    return error


def check_s10(archive):
    s8 = csv_from_zip(archive, "Table_S8A_internal_final_SWAN_scores.csv")
    published = csv_from_zip(archive, "Table_S10_kendall_rank_agreement.csv")
    q = pd.read_csv(INPUTS / "S10_clean_QED_input_20.csv")
    assert len(q) == len(s8) == 20
    assert not q.duplicated(["panel", "Compound"]).any()
    records = q.merge(
        s8[["panel", "Compound", "adme_score", "bestnode_binding",
            "rank_Internal_SWAN_BestNode"]],
        on=["panel", "Compound"], how="inner", validate="one_to_one",
    )
    assert len(records) == 20 and not records.isnull().any().any()
    records["qed"] = records.d_QED
    records["simple"] = (
        records.d_QED * records.adme_score * records.bestnode_binding
    ) ** (1 / 3)
    for col in ("qed", "simple"):
        records[col + "_rank"] = records.groupby("panel")[col].rank(
            ascending=False, method="min"
        )

    computed = []
    for panel, g in records.groupby("panel"):
        for name, rank_col in (
            ("QED-only vs SWAN", "qed_rank"),
            ("QED+ADME+BestNode simple comparator vs SWAN", "simple_rank"),
        ):
            test = kendalltau(g[rank_col], g.rank_Internal_SWAN_BestNode)
            computed.append(dict(panel=panel, comparison=name,
                                 kendall_tau=float(test.statistic),
                                 p_value=float(test.pvalue), n_compounds=len(g)))

    merged = published.merge(pd.DataFrame(computed), on=["panel", "comparison"],
                             suffixes=("_published", "_computed"), validate="one_to_one")
    assert len(merged) == len(published) == 6
    maximum_error = 0.0
    for field in ("kendall_tau", "p_value", "n_compounds"):
        err = (merged[f"{field}_published"] - merged[f"{field}_computed"]).abs().max()
        maximum_error = max(maximum_error, float(err))
        assert float(err) < 1e-12, (field, err)
    print(f"S10 PASS: 6 Kendall rows; largest numerical error {maximum_error:.3g}")


def tie_averaged_bedroc_and_ef(labels, scores, alpha=20.0):
    """Allocate rank-discount and top-k places fractionally within score ties."""
    n = len(labels)
    order = np.argsort(-scores, kind="stable")
    lab = labels[order]
    scr = scores[order]
    n_pos = int(lab.sum())
    prevalence = n_pos / n
    discounts = np.exp(-alpha * np.arange(1, n + 1) / n)
    sums = {int(round(n * f)): 0.0 for f in (0.01, 0.05)}
    numerator = 0.0
    start = 0
    while start < n:
        end = start + 1
        while end < n and scr[end] == scr[start]:
            end += 1
        positives = lab[start:end].sum()
        numerator += positives * discounts[start:end].mean()
        for k in sums:
            sums[k] += positives * max(0, min(end, k) - start) / (end - start)
        start = end
    rie = numerator / (prevalence * discounts.sum())
    best = (1 - math.exp(-alpha * prevalence)) / (prevalence * (1 - math.exp(-alpha)))
    worst = (1 - math.exp(alpha * prevalence)) / (prevalence * (1 - math.exp(alpha)))
    bedroc = (rie - worst) / (best - worst)
    return bedroc, sums[int(round(n * .01))] / round(n * .01) / prevalence, sums[int(round(n * .05))] / round(n * .05) / prevalence


def published_rounding_check(name, expected, observed):
    """Use the decimal precision actually printed in the S11 published cell."""
    displayed = str(expected)
    decimals = len(displayed.partition(".")[2])
    tolerance = 0.5 * 10 ** (-decimals) + 1e-12
    return assert_close(name, observed, expected, tolerance)


def check_s11(archive, profiles):
    published = csv_from_zip(archive, "Table_S11_broad_ChEMBL_metrics.csv")
    mapping = {"SWAN-MPO": "swan_corrected_symmetric",
               "Binding-only": "d_binding", "ADME-only": "d_adme"}
    labels = profiles.label.to_numpy(dtype=int)
    assert len(profiles) == 3980 and int(labels.sum()) == 995
    assert set(labels) == {0, 1}
    largest = 0.0
    for _, row in published.iterrows():
        key = row["Scoring method"]
        scores = profiles[mapping[key]].to_numpy(dtype=float)
        auc = roc_auc_score(labels, scores)
        bedroc, ef1, ef5 = tie_averaged_bedroc_and_ef(labels, scores)
        for field, computed in (("ROC-AUC", auc), ("BEDROC alpha=20", bedroc),
                                ("EF@1%", ef1), ("EF@5%", ef5)):
            largest = max(largest, published_rounding_check(
                f"S11 {key} {field}", row[field], computed))
        assert int(row.n_actives) == 995 and int(row.n_synthetic_profiles) == 2985
        print(f"S11 {key}: AUC={auc:.9f}; BEDROC={bedroc:.9f}; EF1={ef1:.9f}; EF5={ef5:.9f}")
    assert len(published) == 3
    print(f"S11 PASS: all 3 rows / 12 performance metrics match reported rounding; largest displayed difference {largest:.3g}")


def check_s12(archive, profiles):
    published = csv_from_zip(archive, "Table_S12_broad_ChEMBL_DeLong_pairwise_comparisons.csv")
    cols = {"SWAN-MPO": "swan_corrected_symmetric",
            "Binding-only": "d_binding", "ADME-only": "d_adme"}
    labels = profiles.label.to_numpy(dtype=int)
    positives = labels == 1
    negatives = labels == 0
    methods = list(cols)
    aucs, per_pos, per_neg = [], [], []
    for method in methods:
        values = profiles[cols[method]].to_numpy(dtype=float)
        comparisons = values[positives, None] - values[None, negatives]
        credited = (comparisons > 0).astype(float) + 0.5 * (comparisons == 0)
        per_pos.append(credited.mean(axis=1))
        per_neg.append(credited.mean(axis=0))
        aucs.append(credited.mean())
    aucs = np.array(aucs)
    covariance = np.cov(per_pos, ddof=1) / positives.sum() + np.cov(per_neg, ddof=1) / negatives.sum()
    by_name = {method: index for index, method in enumerate(methods)}
    largest = 0.0
    for _, row in published.iterrows():
        i, j = by_name[row.score_a], by_name[row.score_b]
        delta = aucs[i] - aucs[j]
        se = math.sqrt(covariance[i, i] + covariance[j, j] - 2 * covariance[i, j])
        z = delta / se
        p = 2 * norm.sf(abs(z))
        ci = (delta - norm.ppf(0.975) * se, delta + norm.ppf(0.975) * se)
        for field, value in (("auc_a", aucs[i]), ("auc_b", aucs[j]),
                             ("delta_auc", delta), ("se", se), ("z", z),
                             ("p_two_sided", p), ("ci95_low", ci[0]),
                             ("ci95_high", ci[1])):
            largest = max(largest, assert_close(f"S12 {row.score_a} vs {row.score_b} {field}",
                                                value, row[field], tol=1e-11))
        print(f"S12 {row.score_a} vs {row.score_b}: delta={delta:.9f}; se={se:.9f}; p={p:.9g}")
    assert len(published) == 3
    print(f"S12 PASS: all 3 paired DeLong rows / 24 numerical fields match; max error {largest:.3g}")


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python verify_s10_s11_s12.py /path/to/OR2.zip")
    original = Path(sys.argv[1])
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    print(f"OR2 archive SHA-256: {digest}")
    source = INPUTS / "S11_S12_broad_chembl_corrected_profiles_3980.csv"
    expected_source = "2c21418b488f59377744dde2797b38740a1c9bd9f4b69bdabff4ff61df092490"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected_source
    profiles = pd.read_csv(source)
    with zipfile.ZipFile(original) as archive:
        check_s10(archive)
        check_s11(archive, profiles)
        check_s12(archive, profiles)
    print("ALL S10–S12 INDEPENDENT NUMERICAL CHECKS PASSED. ORIGINAL OR2 UNCHANGED.")


if __name__ == "__main__":
    main()
