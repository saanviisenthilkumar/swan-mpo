#!/usr/bin/env python3
"""
Rebuild the broad ChEMBL active–synthetic-profile benchmark with class-symmetric
safety/liability constants and correct enrichment metrics.

Inputs
------
swan_chembl_scores.csv
    The saved 1,097 active rows from the original Step 2 analysis. Required
    columns: mw, logp, tpsa, hbd, hba, rotatable_bonds, d_binding, d_adme.

Outputs
-------
broad_chembl_corrected_profiles.csv
performance_metrics.csv
auc_bootstrap_ci.csv
delong_pairwise.csv
audit_summary.json
analysis_console.txt (when run through tee)

Important
---------
- Reproduces the original synthetic-profile generator using legacy NumPy RNG
  seed 2026 and the original descriptor distributions.
- Sets safety=0.50 and liability=0.60 for BOTH classes.
- Computes EF correctly as top-fraction active rate divided by overall active rate.
- Uses RDKit's CalcBEDROC(alpha=20) rather than the original custom implementation.
- Does not overwrite original manuscript outputs.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import average_precision_score, roc_auc_score

try:
    from rdkit.ML.Scoring.Scoring import CalcBEDROC
except Exception as exc:
    raise SystemExit(
        "RDKit CalcBEDROC is required. Confirm RDKit is installed in this environment."
    ) from exc


def clip_desirability(d: float) -> float:
    return float(np.clip(d, 0.01, 1.00))


def d_window(x: float, A: float, B: float, L: float, U: float) -> float:
    if A <= x <= B:
        return 1.00
    if x < L or x > U:
        return 0.01
    if x < A:
        return clip_desirability((x - L) / (A - L))
    return clip_desirability((U - x) / (U - B))


def geometric_mean(values) -> float:
    vals = np.asarray(values, dtype=float)
    vals = np.clip(vals, 0.01, 1.00)
    return float(np.exp(np.mean(np.log(vals))))


def compute_adme_desirability(row: pd.Series) -> float:
    vals = [
        d_window(float(row["mw"]), 150, 500, 100, 600),
        d_window(float(row["logp"]), -1, 4, -2, 6),
        d_window(float(row["tpsa"]), 20, 140, 0, 200),
        d_window(float(row["hbd"]), 0, 3, 0, 5),
        d_window(float(row["hba"]), 0, 7, 0, 10),
        d_window(float(row["rotatable_bonds"]), 0, 8, 0, 15),
    ]
    return geometric_mean(vals)


def enrichment_factor(y: np.ndarray, scores: np.ndarray, fraction: float) -> float:
    order = np.argsort(-scores, kind="mergesort")
    n = len(y)
    k = max(1, int(np.ceil(fraction * n)))
    prevalence = float(y.mean())
    if prevalence <= 0:
        return float("nan")
    top_rate = float(y[order[:k]].mean())
    return top_rate / prevalence


def bedroc20(y: np.ndarray, scores: np.ndarray) -> float:
    order = np.argsort(-scores, kind="mergesort")
    rows = [[float(scores[i]), int(y[i])] for i in order]
    return float(CalcBEDROC(rows, 1, 20.0))


def performance(name: str, y: np.ndarray, scores: np.ndarray) -> Dict[str, float]:
    return {
        "score": name,
        "n": int(len(y)),
        "n_active": int(y.sum()),
        "n_synthetic": int((1 - y).sum()),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "bedroc20": bedroc20(y, scores),
        "ef1": enrichment_factor(y, scores, 0.01),
        "ef5": enrichment_factor(y, scores, 0.05),
    }


def stratified_bootstrap_auc(
    y: np.ndarray, scores: np.ndarray, n_bootstrap: int, seed: int
) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)
    vals = np.empty(n_bootstrap, dtype=float)
    for i in range(n_bootstrap):
        idx = np.concatenate(
            [
                rng.choice(pos, size=len(pos), replace=True),
                rng.choice(neg, size=len(neg), replace=True),
            ]
        )
        rng.shuffle(idx)
        vals[i] = roc_auc_score(y[idx], scores[idx])
    return {
        "observed_auc": float(roc_auc_score(y, scores)),
        "bootstrap_median": float(np.median(vals)),
        "ci95_low": float(np.quantile(vals, 0.025)),
        "ci95_high": float(np.quantile(vals, 0.975)),
        "n_bootstrap": int(n_bootstrap),
    }


def compute_midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    z = x[order]
    n = len(x)
    t = np.zeros(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j < n and z[j] == z[i]:
            j += 1
        t[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(n, dtype=float)
    out[order] = t
    return out


def fast_delong(preds_sorted: np.ndarray, n_pos: int) -> Tuple[np.ndarray, np.ndarray]:
    m = n_pos
    n = preds_sorted.shape[1] - m
    pos = preds_sorted[:, :m]
    neg = preds_sorted[:, m:]
    k = preds_sorted.shape[0]

    tx = np.empty((k, m))
    ty = np.empty((k, n))
    tz = np.empty((k, m + n))
    for r in range(k):
        tx[r] = compute_midrank(pos[r])
        ty[r] = compute_midrank(neg[r])
        tz[r] = compute_midrank(preds_sorted[r])

    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    if np.ndim(sx) == 0:
        sx = np.array([[float(sx)]])
    if np.ndim(sy) == 0:
        sy = np.array([[float(sy)]])
    return aucs, sx / m + sy / n


def delong_pair(y: np.ndarray, a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    order = np.argsort(-y, kind="mergesort")
    aucs, cov = fast_delong(np.vstack([a, b])[:, order], int(y.sum()))
    contrast = np.array([1.0, -1.0])
    var = float(contrast @ cov @ contrast.T)
    var = max(var, 0.0)
    se = math.sqrt(var)
    delta = float(aucs[0] - aucs[1])
    z = delta / se if se > 0 else (math.inf if delta else 0.0)
    p = 2 * norm.sf(abs(z)) if math.isfinite(z) else 0.0
    return {
        "auc_a": float(aucs[0]),
        "auc_b": float(aucs[1]),
        "delta_auc": delta,
        "se": float(se),
        "z": float(z),
        "p_two_sided": float(p),
        "ci95_low": float(delta - 1.959963984540054 * se),
        "ci95_high": float(delta + 1.959963984540054 * se),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--actives", default="swan_chembl_scores.csv")
    parser.add_argument("--outdir", default="broad_chembl_symmetric_fix")
    parser.add_argument("--decoy-ratio", type=int, default=3)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--bootstrap", type=int, default=10000)
    args = parser.parse_args()

    actives_path = Path(args.actives).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    actives = pd.read_csv(actives_path, low_memory=False)
    required = [
        "mw", "logp", "tpsa", "hbd", "hba", "rotatable_bonds",
        "d_binding", "d_adme"
    ]
    missing = [c for c in required if c not in actives.columns]
    if missing:
        raise ValueError(f"Missing required active columns: {missing}")

    if len(actives) != 995:
        raise ValueError(f"Expected 995 active rows; found {len(actives)}.")

    for c in required:
        actives[c] = pd.to_numeric(actives[c], errors="coerce")
    if actives[required].isna().any().any():
        bad = actives[required].isna().sum()
        raise ValueError(f"Missing/non-numeric active values:\n{bad[bad > 0]}")

    # Preserve original active binding and ADME desirabilities.
    actives_out = actives.copy()
    actives_out["benchmark_class"] = "active"
    actives_out["label"] = 1
    actives_out["d_safety_symmetric"] = 0.50
    actives_out["d_liability_symmetric"] = 0.60
    actives_out["swan_corrected_symmetric"] = np.exp(
        (
            np.log(np.clip(actives_out["d_binding"], 0.01, 1.0))
            + np.log(np.clip(actives_out["d_adme"], 0.01, 1.0))
            + np.log(0.50)
            + np.log(0.60)
        ) / 4.0
    )

    # Reproduce the original synthetic-profile generator exactly.
    rs = np.random.RandomState(args.seed)
    n_synth = len(actives_out) * args.decoy_ratio
    synth = pd.DataFrame()
    synth["profile_id"] = [f"synthetic_{i+1:05d}" for i in range(n_synth)]
    synth["mw"] = rs.normal(
        actives_out["mw"].median(), actives_out["mw"].std() * 1.5, n_synth
    ).clip(100, 800)
    synth["logp"] = rs.normal(
        actives_out["logp"].median(), actives_out["logp"].std() * 1.5, n_synth
    ).clip(-3, 8)
    synth["tpsa"] = rs.normal(
        actives_out["tpsa"].median(), actives_out["tpsa"].std() * 1.5, n_synth
    ).clip(0, 250)
    synth["hbd"] = rs.randint(0, 6, n_synth).astype(float)
    synth["hba"] = rs.randint(0, 12, n_synth).astype(float)
    synth["rotatable_bonds"] = rs.randint(0, 18, n_synth).astype(float)
    synth["d_binding"] = rs.uniform(0.01, 1.00, n_synth)

    # Generate the original asymmetric safety values only for an audit comparator.
    original_asymmetric_safety = rs.uniform(0.20, 0.80, n_synth)

    synth["d_adme"] = synth.apply(compute_adme_desirability, axis=1)
    synth["benchmark_class"] = "synthetic_profile"
    synth["label"] = 0
    synth["d_safety_symmetric"] = 0.50
    synth["d_liability_symmetric"] = 0.60
    synth["swan_corrected_symmetric"] = np.exp(
        (
            np.log(np.clip(synth["d_binding"], 0.01, 1.0))
            + np.log(np.clip(synth["d_adme"], 0.01, 1.0))
            + np.log(0.50)
            + np.log(0.60)
        ) / 4.0
    )
    synth["d_safety_original_asymmetric"] = original_asymmetric_safety
    synth["swan_original_asymmetric_reconstructed"] = np.exp(
        (
            np.log(np.clip(synth["d_binding"], 0.01, 1.0))
            + np.log(np.clip(synth["d_adme"], 0.01, 1.0))
            + np.log(np.clip(original_asymmetric_safety, 0.01, 1.0))
            + np.log(0.60)
        ) / 4.0
    )

    # Active original safety was 0.50, so original and corrected active scores match.
    actives_out["d_safety_original_asymmetric"] = 0.50
    actives_out["swan_original_asymmetric_reconstructed"] = (
        actives_out["swan_corrected_symmetric"]
    )

    keep = [
        "benchmark_class", "label", "mw", "logp", "tpsa", "hbd", "hba",
        "rotatable_bonds", "d_binding", "d_adme",
        "d_safety_symmetric", "d_liability_symmetric",
        "swan_corrected_symmetric",
        "d_safety_original_asymmetric",
        "swan_original_asymmetric_reconstructed",
    ]
    for col in keep:
        if col not in actives_out.columns:
            actives_out[col] = np.nan
        if col not in synth.columns:
            synth[col] = np.nan

    combined = pd.concat([actives_out[keep], synth[keep]], ignore_index=True)
    combined.to_csv(outdir / "broad_chembl_corrected_profiles.csv", index=False)

    y = combined["label"].astype(int).to_numpy()
    scores = {
        "binding_only": combined["d_binding"].to_numpy(float),
        "adme_only": combined["d_adme"].to_numpy(float),
        "swan_original_asymmetric_reconstructed":
            combined["swan_original_asymmetric_reconstructed"].to_numpy(float),
        "swan_corrected_symmetric":
            combined["swan_corrected_symmetric"].to_numpy(float),
    }

    perf = pd.DataFrame(
        [performance(name, y, values) for name, values in scores.items()]
    )
    perf.to_csv(outdir / "performance_metrics.csv", index=False)

    boot_rows = []
    for i, (name, values) in enumerate(scores.items()):
        row = stratified_bootstrap_auc(
            y, values, args.bootstrap, args.seed + 100 + i
        )
        row["score"] = name
        boot_rows.append(row)
    boot = pd.DataFrame(boot_rows)
    boot.to_csv(outdir / "auc_bootstrap_ci.csv", index=False)

    comparisons = [
        ("swan_corrected_symmetric", "binding_only"),
        ("swan_corrected_symmetric", "adme_only"),
        ("swan_corrected_symmetric", "swan_original_asymmetric_reconstructed"),
    ]
    delong_rows = []
    for a, b in comparisons:
        row = delong_pair(y, scores[a], scores[b])
        row["score_a"] = a
        row["score_b"] = b
        delong_rows.append(row)
    delong = pd.DataFrame(delong_rows)
    delong.to_csv(outdir / "delong_pairwise.csv", index=False)

    audit = {
        "input_actives": str(actives_path),
        "n_actives": int((combined["label"] == 1).sum()),
        "n_synthetic_profiles": int((combined["label"] == 0).sum()),
        "total_rows": int(len(combined)),
        "seed": args.seed,
        "decoy_ratio": args.decoy_ratio,
        "bootstrap_iterations": args.bootstrap,
        "safety_value_both_classes": 0.50,
        "liability_value_both_classes": 0.60,
        "synthetic_generator": {
            "mw": "Normal(active median, 1.5 × active SD), clipped 100–800",
            "logp": "Normal(active median, 1.5 × active SD), clipped -3–8",
            "tpsa": "Normal(active median, 1.5 × active SD), clipped 0–250",
            "hbd": "Discrete uniform integers 0–5",
            "hba": "Discrete uniform integers 0–11",
            "rotatable_bonds": "Discrete uniform integers 0–17",
            "binding": "Uniform 0.01–1.00",
        },
        "metric_notes": {
            "ef": "Correct formula: active rate in top fraction / overall active rate",
            "bedroc": "RDKit CalcBEDROC, alpha=20",
        },
    }
    with open(outdir / "audit_summary.json", "w", encoding="utf-8") as fh:
        json.dump(audit, fh, indent=2)

    print("\n=== COUNTS ===")
    print(
        f"Actives: {audit['n_actives']}, "
        f"Synthetic profiles: {audit['n_synthetic_profiles']}, "
        f"Total: {audit['total_rows']}"
    )
    print("\n=== PERFORMANCE ===")
    print(perf.to_string(index=False))
    print("\n=== BOOTSTRAP AUC CI ===")
    print(boot.to_string(index=False))
    print("\n=== DELONG ===")
    print(delong.to_string(index=False))
    print(f"\nOutputs written to: {outdir}")


if __name__ == "__main__":
    main()
