SWAN-MPO machine-readable supplementary tables

Article title:
SWAN-MPO: A Target-Calibrated Multi-Parameter Optimization Framework for Natural-Product Scaffold Triage in Oncology

Manuscript venue (under review):
Scientific Reports

Author:
Saanvii Senthilkumar

Affiliation:
Independent Researcher, Frisco, TX, USA

Corresponding author:
saanviisenthilkumar@gmail.com


PACKAGE CONTENTS

This archive contains the machine-readable CSV files corresponding to Supplementary Tables S1-S24 described in Online Resource 1. The files provide the underlying manifests, docking records, calibration outputs, SWAN-MPO scores, sensitivity analyses, external benchmark results, chemical-space analyses, and parameter definitions used in the study.

Table-specific descriptions, analysis context, and interpretation are provided in Online Resource 1. File names correspond directly to the Supplementary Table numbering used there.


TABLE INDEX

Supplementary Tables S1-S3
Internal and expanded compound manifests and expanded-library docking deployment.

Supplementary Tables S4-S10
Retrospective benchmark manifests, target/PDB definitions, redocking and calibration outputs, internal docking audits, final SWAN-MPO scores, node diagnostics, and rank-agreement analyses.

Supplementary Tables S11-S14
External benchmarking outputs, including the broad ChEMBL benchmark, ChEMBL activity/status and domain-contribution analyses, and descriptor-compatible MPO and drug-likeness comparisons.

Supplementary Tables S15-S16
Curated retrospective benchmark scores and curated-liability ablation results.

Supplementary Tables S17-S19
Ligand-efficiency, strict-top-pose, and Monte Carlo weight-sensitivity analyses.

Supplementary Tables S20-S22
Retrospective PCA, binding-saturation diagnostics, and COCONUT property-space analyses.

Supplementary Table S23
Descriptor-transformation, missing-value, and aggregation parameter dictionary.

Supplementary Table S24
Four-stage internal domain ablation: 177 compound-by-panel scores, stepwise top-10 and rank changes, and leave-one-domain-out comparisons. These results describe internal prioritization effects, not external hit-recovery or safety validation.

REPRODUCIBILITY OF S24
Extract all files and run:
python Reproduction_scripts/run_four_stage_ablation.py --input Table_S8B_expanded_library_final_SWAN_scores.csv --outdir reproduced_S24
Dependencies: Python 3, numpy, pandas, scipy. No new docking or model fitting is required.



INTEGRITY

Supplementary_Table_File_Manifest.csv lists the filename, row count, column count, and SHA-256 checksum for every table CSV included in this archive. Manifest entries are ordered by Supplementary Table number.


BENCHMARK COHORT AND PLACEHOLDER NOTES

Tables S11-S12 evaluate 995 distinct ChEMBL active records against 2,985
generated synthetic comparison profiles (3:1). This exploratory benchmark
uses the same neutral safety and liability placeholders (0.50 and 0.60,
respectively) for both groups. The synthetic profiles are not confirmed
experimentally inactive compounds. The domain-level scoring variant in
these tables is not a full four-domain external safety validation.

Tables S14A-S14C use the corresponding 995-active/2,985-synthetic comparison
cohort for an adapted, descriptor-compatible framework comparison. The
SWAN-compatible comparator assigns the same neutral safety (0.50) and
liability (0.60) placeholders to both classes; the 323 ChEMBL records
without comparable pChEMBL values receive the original deterministic
substitution of 6.0. Early-enrichment statistics are computed using
score-tie-independent expected allocations. The scores compare constructed
ranking behaviors and should not be interpreted as prospective clinical
activity, toxicity, or true experimentally measured inactive recovery.

Table S13 uses a different, 188-record ChEMBL activity/status benchmark.
Table S24 describes 177 internal compound-by-panel ablation scores; its
ranking shifts are not evidence of external biological validation.


BEDROC TIED-SCORE CONVENTION (2026-11-16 CORRECTION)

All reported BEDROC alpha=20 values in Tables S11, S13B-S13D,
S14A, and S16 use tie-invariant expected ranks: for equal scoring
observations, the exponential rank-discount weights over all
occupied ranks are averaged within the tie block, then assigned
equally to observations in that block. The usual finite-sample
RIE minimum/maximum normalization is applied at alpha=20. This
is equivalent to the expectation over random permutations of
records within each tied-score block. It is independent of CSV
input row ordering. Non-BEDROC performance measures and cohort
definitions are unchanged by this correction.

To independently check all 80 S13 BEDROC metrics, extract this ZIP
and run: python Reproduction_scripts/verify_s13_tie_averaged_bedroc.py
The verifier uses only Python's standard library and the
included 188-record S13A source and S13B-S13D result tables.

S13 EIGHT-TARGET SOURCE AND BOOTSTRAP CORRECTION (2026-11-16):
The 188 primary activity/status rows (S13A) are unchanged. The 249-row
A/B/C/D status trace in Reproduction_inputs excludes both 5AR2 rows
and matches S13A on all shared fields for its 188 A/B/C rows.
The S13B/C/D source_file fields now refer to final 5AR2-excluded
publication source exports present in Reproduction_outputs.
These exports are table-split regeneration traces, not independent
original experimental measurements. Source-score reproduction
is described in the forensic audit.
S13C's post hoc class-balanced cluster bootstrap was recomputed
with 5,000 draws, sorted unique parent identifiers, NumPy default_rng
seed 2026, replacement sampling of whole parent clusters, paired
AUC differences, and per-draw A/B/C weight masses of 1/2, 1/4, 1/4.
For P(delta AUC > 0), floating differences <=1e-12 are ties.
See Reproduction_scripts/verify_s13_balanced_cluster_bootstrap.py.
Original balanced-bootstrap results were superseded because their
precise resampling implementation was unrecovered. No other S13
numerical values or any other table's values were changed here.
S16 is explicitly labeled as a historical 15-compound global
four-domain ablation; it is not the final panel-specific S24
ablation, and its metrics must not be compared as equivalent.
S23 source-verification metadata now explicitly identifies 11
rows requiring separate generator or dataset provenance. The
hash-matched canonical primary scoring source is embedded under
Reproduction_scripts for direct inspection.


S22 FULL-UNIVERSE CORRECTION (2026-11-17)
S22A retains its original 23-column schema and verified values.
S22B and S22C use the corrected 738801-compound PCA universe.
Supporting methods, variance, audit results, and descriptor
exceptions are in Reproduction_outputs/S22_full_universe/.


S23 COCONUT IMPLEMENTATION VERIFICATION (2026-11-17)
The six COCONUT parameter rows reference a SHA-256-verified
reconstructed verifier in Reproduction_scripts/.
It reproduces all source-frozen property scores, rankings,
PCA parameters, and nearest neighbors.
The historical original Phase 10 generator was not recovered.
The curated-liability reconstruction verifier is SHA-256-verified and embedded in Reproduction_scripts; the original historical generator remains unavailable.


S10–S12 SOURCE RECOVERY AND INDEPENDENT VERIFICATION (2026-11-17)
The original 49 supplementary table CSVs are unchanged. Original QED
source values and the 3,980-row historical broad ChEMBL predictor-score
dataset were recovered and independently verified against S10–S12.
Run: python Reproduction_scripts/verify_s10_s11_s12.py /path/to/this.zip
Inputs and upstream generator provenance are in Reproduction_inputs/ and
Reproduction_scripts/. See Reproduction_outputs/S10_S11_S12/PROVENANCE.md.
The S11/S12 negatives are synthetic profiles, not measured inactive
compounds; these outcomes are not prospective clinical validation.
Reproduction_File_SHA256SUMS.txt checksums non-table auxiliary files.
The original Phase 12 QED source included obsolete receptor diagnostics
that are excluded from the recovered clean 20-row S10 input and current
eight-target recalculation.
